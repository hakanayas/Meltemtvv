# Meltem TV – Android TV / Xiaomi TV Stick

TV kumandası odaklı sade canlı TV uygulaması.

## Özellikler
- Uygulama adı: Meltem TV
- 33 kanal, başlangıçta Meltem TV ve Malatya Vuslat TV ilk iki sırada
- Yukarı / aşağı ile kanal değiştirme
- OK veya Menü ile kanal listesi
- Menü tuşuna uzun basarak kanal sıralama modu
- Kanal sırası kalıcı olarak cihazda saklanır
- Son izlenen kanal kalıcı olarak saklanır ve uygulama yeniden açılınca devam eder
- Kanal değişiminde 4.5 saniyelik OSD: kanal numarası, kanal adı, saat/tarih
- Android TV / Google TV / Xiaomi TV Stick için landscape arayüz
- Uygulama kendi reklamını eklemez

## Not
Bu sürüm korsan IPTV/m3u listesi içermez. Kanallar yayıncıların resmi canlı yayın sayfalarını WebView içinde açar. Yayıncı web sayfası yapısı değişirse ilgili kanal URL'sinin güncellenmesi gerekebilir. Bazı resmi siteler WebView içinde video oynatmayı engelleyebilir; bu durumda doğrudan resmi HLS/API entegrasyonu için yayıncı izni veya sabit resmi yayın uç noktası gerekir.

## Derleme
Android Studio Quail 4 veya güncel sürümde projeyi açın, Gradle Sync sonrası:
Build > Build APK(s)

Hedef: minSdk 23, target/compile SDK 35.
