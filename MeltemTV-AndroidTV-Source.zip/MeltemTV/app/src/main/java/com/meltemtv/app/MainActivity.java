package com.meltemtv.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static class Channel {
        String id, name, url, shortName;
        Channel(String id, String name, String shortName, String url) {
            this.id=id; this.name=name; this.shortName=shortName; this.url=url;
        }
    }

    private final ArrayList<Channel> defaultChannels = new ArrayList<>();
    private ArrayList<Channel> channels = new ArrayList<>();
    private FrameLayout root;
    private WebView webView;
    private LinearLayout channelPanel;
    private LinearLayout osd;
    private TextView osdTitle, osdProgram, osdTime;
    private boolean listVisible=false;
    private boolean sortMode=false;
    private int selectedIndex=0;
    private int currentIndex=0;
    private Handler handler = new Handler();
    private Runnable hideOsd;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        prefs=getSharedPreferences("meltem_tv", MODE_PRIVATE);
        buildDefaultChannels();
        loadChannelOrder();
        currentIndex = Math.max(0, Math.min(channels.size()-1, prefs.getInt("last_channel",0)));
        selectedIndex=currentIndex;
        buildUi();
        playChannel(currentIndex, false);
    }

    private void buildDefaultChannels() {
        // Official broadcaster live pages where available. Channels without a stable public TV URL
        // use the broadcaster homepage until an official live endpoint is confirmed.
        add("meltem", "Meltem TV", "MELTEM", "https://www.meltemtv.com.tr/");
        add("vuslat", "Malatya Vuslat TV", "VUSLAT", "https://www.vuslattv.com.tr/");
        add("atv", "ATV", "aTV", "https://www.atv.com.tr/canli-yayin");
        add("atveuro", "ATV Avrupa", "aTV EU", "https://www.atvavrupa.tv/");
        add("trt1", "TRT 1", "TRT 1", "https://www.tabii.com/tr/watch/live/trt1");
        add("show", "Show TV", "SHOW", "https://www.showtv.com.tr/canli-yayin");
        add("kanald", "Kanal D", "KANAL D", "https://www.kanald.com.tr/canli-yayin");
        add("star", "Star TV", "STAR", "https://www.startv.com.tr/canli-yayin");
        add("tv8", "TV8", "TV8", "https://www.tv8.com.tr/canli-yayin");
        add("now", "NOW", "NOW", "https://www.nowtv.com.tr/canli-yayin");
        add("kanal7", "Kanal 7", "KANAL 7", "https://www.kanal7.com/canli-izle");
        add("teve2", "teve2", "teve2", "https://www.teve2.com.tr/canli-yayin");
        add("a2", "a2", "a2", "https://www.a2tv.com.tr/canli-yayin");
        add("trt2", "TRT 2", "TRT 2", "https://www.tabii.com/tr/watch/live/trt2");
        add("tlc", "TLC", "TLC", "https://www.tlctv.com.tr/canli-izle");
        add("dmax", "DMAX", "DMAX", "https://www.dmax.com.tr/canli-izle");
        add("tv85", "TV8,5", "TV8,5", "https://www.tv8bucuk.com/");
        add("trtbelgesel", "TRT Belgesel", "TRT BEL", "https://www.tabii.com/tr/watch/live/trtbelgesel");
        add("trtspor", "TRT Spor", "TRT SPOR", "https://www.trtspor.com.tr/canli-yayin-izle/trt-spor/");
        add("trtsporyildiz", "TRT Spor Yıldız", "YILDIZ", "https://www.trtspor.com.tr/canli-yayin-izle/trt-spor-yildiz/");
        add("aspor", "A Spor", "A SPOR", "https://www.aspor.com.tr/webtv/canli-yayin");
        add("trthaber", "TRT Haber", "TRT HABER", "https://www.trthaber.com/canli-yayin.html");
        add("ntv", "NTV", "NTV", "https://www.ntv.com.tr/canli-yayin/ntv");
        add("cnnturk", "CNN Türk", "CNN TÜRK", "https://www.cnnturk.com/canli-yayin");
        add("haberturk", "Habertürk", "HABERTÜRK", "https://www.haberturk.com/canliyayin");
        add("ahaber", "A Haber", "A HABER", "https://www.ahaber.com.tr/video/canli-yayin");
        add("tgrt", "TGRT Haber", "TGRT", "https://www.tgrthaber.com/canli-yayin");
        add("bloomberg", "Bloomberg HT", "BLOOMBERG", "https://www.bloomberght.com/canli-yayin");
        add("cnbce", "CNBC-e", "CNBC-e", "https://www.cnbce.com/canli-yayin");
        add("trtmuzik", "TRT Müzik", "TRT MÜZİK", "https://www.tabii.com/tr/watch/live/trtmuzik");
        add("trtcocuk", "TRT Çocuk", "TRT ÇOCUK", "https://www.tabii.com/tr/watch/live/trtcocuk");
        add("minikacocuk", "Minika Çocuk", "MINIKA", "https://www.minikacocuk.com.tr/");
        add("minikago", "Minika GO", "MINIKA GO", "https://www.minikago.com.tr/");
    }
    private void add(String id,String name,String shortName,String url){ defaultChannels.add(new Channel(id,name,shortName,url)); }

    private void loadChannelOrder(){
        String saved=prefs.getString("channel_order","");
        if(saved.isEmpty()){ channels=new ArrayList<>(defaultChannels); return; }
        Map<String,Channel> map=new HashMap<>(); for(Channel c:defaultChannels) map.put(c.id,c);
        channels.clear();
        for(String id:saved.split(",")){ Channel c=map.remove(id); if(c!=null) channels.add(c); }
        channels.addAll(map.values());
    }
    private void saveOrder(){
        StringBuilder b=new StringBuilder(); for(Channel c:channels){ if(b.length()>0)b.append(','); b.append(c.id); }
        prefs.edit().putString("channel_order",b.toString()).apply();
    }

    private GradientDrawable bg(int color,int radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    private TextView text(String s,int sp,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(12,7,12,7); return t; }

    private void buildUi(){
        root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK); setContentView(root);
        webView=new WebView(this); root.addView(webView,new FrameLayout.LayoutParams(-1,-1));
        WebSettings ws=webView.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setMediaPlaybackRequiresUserGesture(false); ws.setLoadWithOverviewMode(true); ws.setUseWideViewPort(true); ws.setUserAgentString(ws.getUserAgentString()+" MeltemTV/1.0 AndroidTV");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        buildChannelPanel(); buildOsd();
    }

    private void buildChannelPanel(){
        channelPanel=new LinearLayout(this); channelPanel.setOrientation(LinearLayout.VERTICAL); channelPanel.setPadding(18,18,18,18); channelPanel.setBackground(bg(0xEE071019,18));
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(dp(390),-1,Gravity.LEFT); p.setMargins(14,14,0,14); root.addView(channelPanel,p); channelPanel.setVisibility(View.GONE);
    }

    private void refreshChannelPanel(){
        channelPanel.removeAllViews();
        TextView header=text(sortMode?"Kanal Sıralaması":"TV Kanalları",24,Color.WHITE); header.setTypeface(Typeface.DEFAULT,Typeface.BOLD); channelPanel.addView(header,new LinearLayout.LayoutParams(-1,dp(54)));
        ScrollView sv=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); sv.addView(list,new ScrollView.LayoutParams(-1,-2));
        for(int i=0;i<channels.size();i++){
            Channel c=channels.get(i); TextView row=text((i+1)+"   "+c.shortName+"   "+c.name,18,Color.WHITE);
            if(i==selectedIndex) row.setBackground(bg(0xFF168DE2,14)); else row.setBackground(bg(0x33000000,14));
            list.addView(row,new LinearLayout.LayoutParams(-1,dp(48)));
        }
        TextView hint=text(sortMode?"OK: taşıma aç/kapat   ↑↓: seç/taşı   Geri: kaydet":"↑↓: kanal değiştir   OK: aç   Menü: kapat   Menü uzun bas: sırala",14,0xFFB9C8D8);
        list.addView(hint,new LinearLayout.LayoutParams(-1,dp(64)));
        if(sortMode){ TextView reset=text("Varsayılan sıralamaya dönmek için SOL tuşuna bas",14,0xFFFFC36B); list.addView(reset,new LinearLayout.LayoutParams(-1,dp(50))); }
        channelPanel.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    }

    private void buildOsd(){
        osd=new LinearLayout(this); osd.setOrientation(LinearLayout.VERTICAL); osd.setPadding(22,14,22,14); osd.setBackground(bg(0xDD071019,18));
        osdTitle=text("",26,Color.WHITE); osdTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        osdProgram=text("Canlı yayın",18,0xFFE8F2FF); osdTime=text("",15,0xFFB8C6D6);
        osd.addView(osdTitle); osd.addView(osdProgram); osd.addView(osdTime);
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(dp(620),dp(140),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); p.setMargins(0,0,0,34); root.addView(osd,p); osd.setVisibility(View.GONE);
        hideOsd=()->osd.setVisibility(View.GONE);
    }

    private void showOsd(){
        Channel c=channels.get(currentIndex); osdTitle.setText((currentIndex+1)+"   "+c.name);
        osdProgram.setText("Canlı yayın");
        osdTime.setText(new SimpleDateFormat("HH:mm   dd MMMM yyyy",new Locale("tr","TR")).format(new Date()));
        osd.setVisibility(View.VISIBLE); handler.removeCallbacks(hideOsd); handler.postDelayed(hideOsd,4500);
    }

    private void playChannel(int idx, boolean show){
        if(channels.isEmpty()) return; currentIndex=(idx+channels.size())%channels.size(); selectedIndex=currentIndex;
        prefs.edit().putInt("last_channel",currentIndex).apply();
        webView.loadUrl(channels.get(currentIndex).url);
        if(show) showOsd();
    }
    private void next(int d){ playChannel(currentIndex+d,true); }

    private boolean moving=false;
    @Override public boolean onKeyDown(int key, KeyEvent e){
        if(key==KeyEvent.KEYCODE_MENU && e.getRepeatCount()>0){ if(!sortMode){ sortMode=true; moving=false; listVisible=true; channelPanel.setVisibility(View.VISIBLE); refreshChannelPanel(); } return true; }
        if(key==KeyEvent.KEYCODE_MENU){ if(sortMode){ saveOrder(); sortMode=false; moving=false; } listVisible=!listVisible; channelPanel.setVisibility(listVisible?View.VISIBLE:View.GONE); if(listVisible) refreshChannelPanel(); return true; }
        if(sortMode){
            if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER){ moving=!moving; Toast.makeText(this,moving?"Taşıma açık":"Taşıma kapalı",Toast.LENGTH_SHORT).show(); return true; }
            if(key==KeyEvent.KEYCODE_DPAD_LEFT){ channels=new ArrayList<>(defaultChannels); selectedIndex=0; saveOrder(); refreshChannelPanel(); Toast.makeText(this,"Varsayılan sıra geri yüklendi",Toast.LENGTH_SHORT).show(); return true; }
            if(key==KeyEvent.KEYCODE_DPAD_UP||key==KeyEvent.KEYCODE_DPAD_DOWN){
                int d=key==KeyEvent.KEYCODE_DPAD_UP?-1:1; int n=Math.max(0,Math.min(channels.size()-1,selectedIndex+d));
                if(moving && n!=selectedIndex){ Collections.swap(channels,selectedIndex,n); selectedIndex=n; saveOrder(); }
                else selectedIndex=n; refreshChannelPanel(); return true;
            }
            if(key==KeyEvent.KEYCODE_BACK){ saveOrder(); sortMode=false; moving=false; listVisible=false; channelPanel.setVisibility(View.GONE); currentIndex=Math.min(currentIndex,channels.size()-1); return true; }
        }
        if(listVisible){
            if(key==KeyEvent.KEYCODE_DPAD_UP){ selectedIndex=(selectedIndex-1+channels.size())%channels.size(); refreshChannelPanel(); return true; }
            if(key==KeyEvent.KEYCODE_DPAD_DOWN){ selectedIndex=(selectedIndex+1)%channels.size(); refreshChannelPanel(); return true; }
            if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER){ playChannel(selectedIndex,true); listVisible=false; channelPanel.setVisibility(View.GONE); return true; }
            if(key==KeyEvent.KEYCODE_BACK){ listVisible=false; channelPanel.setVisibility(View.GONE); return true; }
        } else {
            if(key==KeyEvent.KEYCODE_DPAD_UP){ next(-1); return true; }
            if(key==KeyEvent.KEYCODE_DPAD_DOWN){ next(1); return true; }
            if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER){ listVisible=true; selectedIndex=currentIndex; channelPanel.setVisibility(View.VISIBLE); refreshChannelPanel(); return true; }
            if(key==KeyEvent.KEYCODE_BACK){ if(webView.canGoBack()){ webView.goBack(); return true; } }
        }
        return super.onKeyDown(key,e);
    }
    @Override protected void onPause(){ super.onPause(); prefs.edit().putInt("last_channel",currentIndex).apply(); }
    private int dp(int x){ return (int)(x*getResources().getDisplayMetrics().density+0.5f); }
}
